﻿using fluxodecaixa.Forms;
using fluxodecaixa.Model;
using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;

namespace fluxodecaixa
{
    public partial class frmCadastrarProduto : Form
    {
        public frmCadastrarProduto()
        {
            InitializeComponent();
        }


        private void frmCadastrarProduto_Load(object sender, EventArgs e)
        {
            using (var db = new DatabaseContexto())
            {
                populateProdutos();
                populateFornecedores();
            }
        }

        private void btnSalvarProduto_Click(object sender, EventArgs e)
        {
            if(txtNomeProduto.TextLength == 0 || txtPrecoVenda.TextLength == 0 || numericQtdProduto.Value <= 0)
            {
                MessageBox.Show("Informações inválidas");
                return;
            }

            Fornecedor fornecedor = comboFornecedores.SelectedItem as Fornecedor;
            if (fornecedor == null)
            {
                MessageBox.Show("Selecione um fornecedor");
                return;
            }

            Produto produto = new Produto();
            produto.Nome = txtNomeProduto.Text;
            produto.PrecoVenda = Convert.ToSingle(txtPrecoVenda.Text);
            produto.PrecoCusto = Convert.ToSingle(txtPrecoCusto.Text);
            produto.QtdEstoque = decimal.ToInt32(numericQtdProduto.Value);
            
            using (var db = new DatabaseContexto())
            {
                db.Attach(fornecedor);
                fornecedor.Produtos.Add(produto);
                db.SaveChanges();
            }

            populateProdutos();
            txtNomeProduto.Text = "";
            txtPrecoVenda.Text = "";
            numericQtdProduto.Value = 1;
        }

        private void txtPrecoProduto_TextChanged(object sender, EventArgs e)
        {
            TextBoxValidationDelegate validationDelegate = new TextBoxValidationDelegate();
            validationDelegate.clearIfNotMoney(txtPrecoVenda);
        }

        private void btnAdicionarFornecedor_Click(object sender, EventArgs e)
        {
            using (FormCadastrarFornecedor formCadastrarFornecedor = new FormCadastrarFornecedor())
            {
                if(formCadastrarFornecedor.ShowDialog() == DialogResult.OK)
                {
                    populateFornecedores();
                }
            }
        }

        private void populateProdutos()
        {
            using(var db = new DatabaseContexto())
            {
                var produtosList = db.Produtos.ToList();
                var bindingList = new BindingList<Produto>(produtosList);
                var source = new BindingSource(bindingList, null);
                estoqueGridView.DataSource = source;
            }            
        }
        private void populateFornecedores()
        {
            using(var db = new DatabaseContexto())
            {
                var fornecedoresList = db.Fornecedores.ToList();
                var fornecedoresBindingList = new BindingList<Fornecedor>(fornecedoresList);
                var fornecedoresSource = new BindingSource(fornecedoresBindingList, null);
                comboFornecedores.DataSource = fornecedoresSource;
                comboFornecedores.DisplayMember = "Nome";
            }
        }

        private void estoqueGridView_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            var NomeColuna = estoqueGridView.Columns[e.ColumnIndex].Name;
            if(NomeColuna.Equals("Custo") || NomeColuna.Equals("Venda"))
            {
                Double preco = Convert.ToDouble(e.Value);
                if (preco == null) return;
                e.Value = preco.ToString("F2");
            }
        }
    }
}
