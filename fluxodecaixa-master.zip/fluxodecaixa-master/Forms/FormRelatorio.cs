﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;
using fluxodecaixa;
using fluxodecaixa.Forms;
using fluxodecaixa.Model;
using Microsoft.EntityFrameworkCore;

namespace sys_caixa.Forms
{
    public partial class FormRelatorio : Form
    {
        public static string ULTIMOS_5_MINUTOS = "ULTIMOS 5 MINUTOS";
        public static string ULTIMA_HORA = "ULTIMA HORA";
        public static string ULTIMO_DIA = "ULTIMO DIA";
        public static string ULTIMA_SEMANA = "ULTIMA SEMANA";
        public static string ULTIMO_MES = "ULTIMO MÊS";
        public static string ULTIMO_ANO = "ULTIMO ANO";

        public FormRelatorio()
        {
            InitializeComponent();
            inicializarOpcoes();
        }

        public void inicializarOpcoes()
        {
            cbxPeriodo.Items.Insert(0, ULTIMOS_5_MINUTOS);
            cbxPeriodo.Items.Insert(1, ULTIMA_HORA);
            cbxPeriodo.Items.Insert(2, ULTIMO_DIA);
            cbxPeriodo.Items.Insert(3, ULTIMA_SEMANA);
            cbxPeriodo.Items.Insert(4, ULTIMO_MES);
            cbxPeriodo.Items.Insert(5, ULTIMO_ANO);
        }

        private void cbxPeriodo_SelectedValueChanged(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            cbxPeriodo.Enabled = false;
            gerarRelatorio();
            cbxPeriodo.Enabled = true;
            Cursor.Current = Cursors.Default;
        }

        public void gerarRelatorio()
        {
            string periodo = cbxPeriodo.Text;
            using (var db = new DatabaseContexto())
            {
                try
                {
                    DateTime dataInicio = DateTime.Now;
                    DateTime dataFim = DateTime.Now;

                    if (periodo.Equals(ULTIMOS_5_MINUTOS))
                        dataInicio = dataInicio.AddMinutes(-5);

                    else if (periodo.Equals(ULTIMA_HORA))
                        dataInicio = dataInicio.AddHours(-1);

                    else if (periodo.Equals(FormRelatorio.ULTIMO_DIA))
                        dataInicio = dataInicio.AddDays(-1);

                    else if (periodo.Equals(FormRelatorio.ULTIMA_SEMANA))
                        dataInicio = dataInicio.AddDays(-7);

                    else if (periodo.Equals(FormRelatorio.ULTIMO_MES))
                        dataInicio = dataInicio.AddMonths(-1);

                    else
                        dataInicio = dataInicio.AddYears(-1);

                    var result = (from v in db.Vendas
                                  where v.TimeStamp > dataInicio
                                  && v.TimeStamp <= dataFim
                                  select new { 
                                      v.Id,
                                      Funcionario = v.Funcionario.Nome,
                                      Data = v.TimeStamp,
                                      v.Valor,
                                      v.FormaPagamento
                                  }).ToList();

                    if (result.Count() <= 0)
                    {
                        MessageBox.Show("Não há registros para esse período", "Ops!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        dataGridRelatorio.DataSource = null;
                        datGridPedido.DataSource = null;
                    }
                    else
                    {
                        dataGridRelatorio.AutoGenerateColumns = false;
                        dataGridRelatorio.DataSource = result;
                        dataGridRelatorio.Refresh();
                        datGridPedido.Refresh();

                        var total = result.Sum((i) => i.Valor);
                        lblTotal.Text = StringUtil.formatToReais(total);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void dataGridRelatorio_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            datGridPedido.AutoGenerateColumns = false;
            Cursor.Current = Cursors.WaitCursor;
            var vendaId = Convert.ToInt32(dataGridRelatorio.Rows[e.RowIndex].Cells[0].Value);

            using(var db = new DatabaseContexto())
            {
                var result = (from i in db.ItensVenda
                              where i.Venda.Id == vendaId
                              select new
                              {
                                  i.Produto.Nome,
                                  i.Produto.PrecoVenda,
                                  i.QtdVenda,
                                  Total = i.QtdVenda * i.Produto.PrecoVenda
                              }).ToList();

                datGridPedido.DataSource = result;
                datGridPedido.Refresh();
                Cursor.Current = Cursors.WaitCursor;
            }
        }

        private void dataGridRelatorio_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            var NomeColuna = dataGridRelatorio.Columns[e.ColumnIndex].Name;
            if (NomeColuna.Equals("Valor"))
            {
                Double preco = Convert.ToDouble(e.Value);
                if (preco == null) return;
                e.Value = preco.ToString("F2");
            }
        }
    }
}