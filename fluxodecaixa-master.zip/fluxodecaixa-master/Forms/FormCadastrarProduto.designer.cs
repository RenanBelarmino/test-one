﻿namespace fluxodecaixa
{
    partial class frmCadastrarProduto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCadastrarProduto));
            this.txtNomeProduto = new System.Windows.Forms.TextBox();
            this.txtPrecoVenda = new System.Windows.Forms.TextBox();
            this.estoqueGridView = new System.Windows.Forms.DataGridView();
            this.Cod = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nome = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Venda = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Custo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Qtd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.produtosBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.btnSalvarProduto = new System.Windows.Forms.Button();
            this.labelQtdProduto = new System.Windows.Forms.Label();
            this.numericQtdProduto = new System.Windows.Forms.NumericUpDown();
            this.comboFornecedores = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnAdicionarFornecedor = new System.Windows.Forms.Button();
            this.txtPrecoCusto = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.estoqueGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.produtosBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericQtdProduto)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtNomeProduto
            // 
            this.txtNomeProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomeProduto.Location = new System.Drawing.Point(18, 48);
            this.txtNomeProduto.Name = "txtNomeProduto";
            this.txtNomeProduto.Size = new System.Drawing.Size(216, 26);
            this.txtNomeProduto.TabIndex = 0;
            // 
            // txtPrecoVenda
            // 
            this.txtPrecoVenda.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrecoVenda.Location = new System.Drawing.Point(24, 143);
            this.txtPrecoVenda.Name = "txtPrecoVenda";
            this.txtPrecoVenda.Size = new System.Drawing.Size(70, 26);
            this.txtPrecoVenda.TabIndex = 3;
            this.txtPrecoVenda.TextChanged += new System.EventHandler(this.txtPrecoProduto_TextChanged);
            // 
            // estoqueGridView
            // 
            this.estoqueGridView.AllowUserToAddRows = false;
            this.estoqueGridView.AllowUserToDeleteRows = false;
            this.estoqueGridView.AllowUserToResizeColumns = false;
            this.estoqueGridView.AllowUserToResizeRows = false;
            this.estoqueGridView.AutoGenerateColumns = false;
            this.estoqueGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.estoqueGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.estoqueGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Cod,
            this.Nome,
            this.Venda,
            this.Custo,
            this.Qtd});
            this.estoqueGridView.DataSource = this.produtosBindingSource;
            this.estoqueGridView.Location = new System.Drawing.Point(257, 24);
            this.estoqueGridView.Name = "estoqueGridView";
            this.estoqueGridView.ReadOnly = true;
            this.estoqueGridView.RowHeadersWidth = 51;
            this.estoqueGridView.Size = new System.Drawing.Size(538, 351);
            this.estoqueGridView.TabIndex = 6;
            this.estoqueGridView.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.estoqueGridView_CellFormatting);
            // 
            // Cod
            // 
            this.Cod.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Cod.DataPropertyName = "Id";
            this.Cod.HeaderText = "Cod";
            this.Cod.MinimumWidth = 6;
            this.Cod.Name = "Cod";
            this.Cod.ReadOnly = true;
            this.Cod.Width = 51;
            // 
            // Nome
            // 
            this.Nome.DataPropertyName = "Nome";
            this.Nome.HeaderText = "Nome";
            this.Nome.MinimumWidth = 6;
            this.Nome.Name = "Nome";
            this.Nome.ReadOnly = true;
            // 
            // Venda
            // 
            this.Venda.DataPropertyName = "PrecoVenda";
            this.Venda.HeaderText = "Preço Venda";
            this.Venda.MinimumWidth = 6;
            this.Venda.Name = "Venda";
            this.Venda.ReadOnly = true;
            // 
            // Custo
            // 
            this.Custo.DataPropertyName = "PrecoCusto";
            this.Custo.HeaderText = "Preço Custo";
            this.Custo.MinimumWidth = 6;
            this.Custo.Name = "Custo";
            this.Custo.ReadOnly = true;
            // 
            // Qtd
            // 
            this.Qtd.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Qtd.DataPropertyName = "QtdEstoque";
            this.Qtd.HeaderText = "Quantidade";
            this.Qtd.MinimumWidth = 6;
            this.Qtd.Name = "Qtd";
            this.Qtd.ReadOnly = true;
            this.Qtd.Width = 87;
            // 
            // produtosBindingSource
            // 
            this.produtosBindingSource.DataMember = "Produtos";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(14, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Nome";
            // 
            // btnSalvarProduto
            // 
            this.btnSalvarProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalvarProduto.Location = new System.Drawing.Point(73, 332);
            this.btnSalvarProduto.Name = "btnSalvarProduto";
            this.btnSalvarProduto.Size = new System.Drawing.Size(91, 28);
            this.btnSalvarProduto.TabIndex = 6;
            this.btnSalvarProduto.Text = "Cadastrar";
            this.btnSalvarProduto.UseVisualStyleBackColor = true;
            this.btnSalvarProduto.Click += new System.EventHandler(this.btnSalvarProduto_Click);
            // 
            // labelQtdProduto
            // 
            this.labelQtdProduto.AutoSize = true;
            this.labelQtdProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelQtdProduto.Location = new System.Drawing.Point(16, 191);
            this.labelQtdProduto.Name = "labelQtdProduto";
            this.labelQtdProduto.Size = new System.Drawing.Size(92, 20);
            this.labelQtdProduto.TabIndex = 7;
            this.labelQtdProduto.Text = "Quantidade";
            // 
            // numericQtdProduto
            // 
            this.numericQtdProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericQtdProduto.Location = new System.Drawing.Point(20, 214);
            this.numericQtdProduto.Name = "numericQtdProduto";
            this.numericQtdProduto.Size = new System.Drawing.Size(76, 26);
            this.numericQtdProduto.TabIndex = 4;
            this.numericQtdProduto.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // comboFornecedores
            // 
            this.comboFornecedores.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.comboFornecedores.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.comboFornecedores.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboFornecedores.FormattingEnabled = true;
            this.comboFornecedores.Location = new System.Drawing.Point(18, 276);
            this.comboFornecedores.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboFornecedores.Name = "comboFornecedores";
            this.comboFornecedores.Size = new System.Drawing.Size(192, 28);
            this.comboFornecedores.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(16, 254);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 20);
            this.label3.TabIndex = 10;
            this.label3.Text = "Fornecedor";
            // 
            // btnAdicionarFornecedor
            // 
            this.btnAdicionarFornecedor.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAdicionarFornecedor.BackgroundImage")));
            this.btnAdicionarFornecedor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAdicionarFornecedor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAdicionarFornecedor.Location = new System.Drawing.Point(213, 279);
            this.btnAdicionarFornecedor.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnAdicionarFornecedor.Name = "btnAdicionarFornecedor";
            this.btnAdicionarFornecedor.Size = new System.Drawing.Size(20, 22);
            this.btnAdicionarFornecedor.TabIndex = 11;
            this.btnAdicionarFornecedor.UseVisualStyleBackColor = true;
            this.btnAdicionarFornecedor.Click += new System.EventHandler(this.btnAdicionarFornecedor_Click);
            // 
            // txtPrecoCusto
            // 
            this.txtPrecoCusto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrecoCusto.Location = new System.Drawing.Point(6, 24);
            this.txtPrecoCusto.Name = "txtPrecoCusto";
            this.txtPrecoCusto.Size = new System.Drawing.Size(71, 26);
            this.txtPrecoCusto.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(86, 28);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 17);
            this.label4.TabIndex = 12;
            this.label4.Text = "Custo";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(87, 61);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 17);
            this.label5.TabIndex = 13;
            this.label5.Text = "Venda";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtPrecoCusto);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(18, 87);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(140, 88);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Preço";
            // 
            // frmCadastrarProduto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(771, 404);
            this.Controls.Add(this.btnAdicionarFornecedor);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboFornecedores);
            this.Controls.Add(this.numericQtdProduto);
            this.Controls.Add(this.labelQtdProduto);
            this.Controls.Add(this.btnSalvarProduto);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.estoqueGridView);
            this.Controls.Add(this.txtPrecoVenda);
            this.Controls.Add(this.txtNomeProduto);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmCadastrarProduto";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Estoque";
            this.Load += new System.EventHandler(this.frmCadastrarProduto_Load);
            ((System.ComponentModel.ISupportInitialize)(this.estoqueGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.produtosBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericQtdProduto)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNomeProduto;
        private System.Windows.Forms.TextBox txtPrecoVenda;
        private System.Windows.Forms.DataGridView estoqueGridView;
        private System.Windows.Forms.BindingSource produtosBindingSource;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSalvarProduto;
        private System.Windows.Forms.Label labelQtdProduto;
        private System.Windows.Forms.NumericUpDown numericQtdProduto;
        private System.Windows.Forms.ComboBox comboFornecedores;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnAdicionarFornecedor;
        private System.Windows.Forms.TextBox txtPrecoCusto;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cod;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nome;
        private System.Windows.Forms.DataGridViewTextBoxColumn Venda;
        private System.Windows.Forms.DataGridViewTextBoxColumn Custo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Qtd;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}