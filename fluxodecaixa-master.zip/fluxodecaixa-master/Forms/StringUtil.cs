﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fluxodecaixa.Forms
{
    class StringUtil
    {
        public static String formatToReais(double valor)
        {
            return string.Format(CultureInfo.CreateSpecificCulture("pt-br"), "{0:N2}", valor);
        }
    }
}
