﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore.Internal;

namespace fluxodecaixa.Forms
{
    class TextBoxValidationDelegate
    {
        public void clearIfNotNumber(TextBox text)
        {
            char[] array =  text.Text.ToCharArray();
            if(array.Length > 0)
            {
                char keyChar = array.Last();
                if (Char.IsNumber(keyChar) && Char.IsDigit(keyChar)) return;
                text.Text = "";
                text.ClearUndo();
            }
        }

        public void clearIfNotMoney(TextBox text)
        {
            if (text.Text.Length > 0)
            {
                char[] array = text.Text.ToCharArray();
                if (array.Length > 0)
                {
                    char keyChar = array.Last();
                    if (keyChar.Equals(',')) return;
                    if (Char.IsNumber(keyChar) && Char.IsDigit(keyChar)) return; 
                    text.Text = "";
                    text.ClearUndo();
                }
            }
        }
    }
}
