﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using fluxodecaixa.Model;

namespace fluxodecaixa.Forms
{
    public partial class FormCadastrarFornecedor : Form
    {
        public FormCadastrarFornecedor()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using(var db = new DatabaseContexto())
            {
                Fornecedor novoFornecedor = new Fornecedor();
                novoFornecedor.Nome = txtNomeFornecedor.Text;
                novoFornecedor.Telefone = txtContatoFornecedor.Text;
                db.Fornecedores.Add(novoFornecedor);
                db.SaveChanges();
            }

            this.DialogResult = DialogResult.OK;
            this.Hide();
        }
    }
}
