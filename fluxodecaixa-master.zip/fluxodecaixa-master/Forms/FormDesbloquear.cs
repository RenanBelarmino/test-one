﻿using System;
using System.Windows.Forms;

namespace fluxodecaixa
{
    public partial class frmGerente : Form
    {
        public frmGerente()
        {
            InitializeComponent();
        }
        protected void button1_Click(object sender, EventArgs e)
        {
            if (txtLogiGerente.Text == "100" && txtSenhagerente.Text == "9494")
            {
                FormCadastroFuncionario y = new FormCadastroFuncionario();
                y.Show();
                this.Hide();
                this.Close();
            }
            else
                MessageBox.Show("Somente o gerente pode fazer essa operação!");
        }

        private void txtSenhagerente_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                button1_Click(sender, e);
            }
        }
    }
}
