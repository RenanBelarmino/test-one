﻿using fluxodecaixa.Forms;
using fluxodecaixa.Model;
using sys_caixa.Forms;
using System;
using System.ComponentModel;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace fluxodecaixa
{
    public partial class Principal : Form
    {
        private static Principal instance = null;
        internal static Funcionario _funcionario;
        private double _totalVenda = 0;
        BindingList<ItemVenda> bindingList = new BindingList<ItemVenda>();
        public Principal()
        {
            InitializeComponent();
            instance = this;

        }

        internal static Principal getInstance(Funcionario funcionario)
        {
            if(instance == null)
            {
                instance = new Principal();
                _funcionario = funcionario;
            }

            return instance;
        }

        private void Principal_Load(object sender, EventArgs e)
        {
            vendaGridView.AutoGenerateColumns = false;
            lblOperador.Text = "Operador: " + _funcionario.Nome;
            txtCodProduto.Focus();
            esconderBotaoVender();
        }

        public void reiniciarPedido()
        {
            bindingList.Clear();
            txtTotal.Clear();
            esconderBotaoVender();
        }

        private void btCadastroProduto_Click(object sender, EventArgs e)
        {
            frmCadastrarProduto y = new frmCadastrarProduto();
            y.Show();
        }

        private void txtCodProduto_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtQuantidade.Focus();
            }   
        }

        private void txtQuantidade_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && txtCodProduto.TextLength > 0 && txtQuantidade.TextLength > 0)
            {
                int quantidade = int.Parse(txtQuantidade.Text);
                int cod = int.Parse(txtCodProduto.Text);

                using (var db = new DatabaseContexto())
                {
                    try
                    {
                        if (vendaGridView.DataSource == null)
                        {
                            vendaGridView.DataSource = bindingList;
                        }

                        ItemVenda itemVenda = null;
                        Produto produto = null;
                        try
                        {
                            itemVenda = bindingList.Where(i => i.Produto.Id == cod).First();
                            produto = itemVenda.Produto;
                        }
                        catch (Exception)
                        {
                            produto = db.Produtos.Where(p => p.Id == cod).First();
                        }

                        if (quantidade > produto.QtdEstoque)
                        {
                            MessageBox.Show("Só há " + produto.QtdEstoque + " itens desse produto em estoque.");
                            return;
                        }

                        produto.QtdEstoque -= quantidade;
                        if (itemVenda != null)
                        {
                            itemVenda.QtdVenda += quantidade;
                            bindingList.ResetItem(bindingList.IndexOf(itemVenda));
                        }
                        else
                        {
                            itemVenda = new ItemVenda(quantidade);
                            itemVenda.Produto = produto;
                            bindingList.Add(itemVenda);
                        }

                        if(bindingList.Count > 0)
                        {
                            mostrarBotaoVender();
                        }
                        else
                        {
                            esconderBotaoVender();
                        }

                        _totalVenda = bindingList.Sum((item) => item.Total);
                        txtTotal.Text = StringUtil.formatToReais(_totalVenda);
                        txtCodProduto.Text = "";
                        txtQuantidade.Text = "";
                        txtCodProduto.Focus();
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Produto não cadastrado!");
                    }
                }
            }
        }


        private void txtCodProduto_TextChanged(object sender, EventArgs e)
        {
            TextBoxValidationDelegate validationDelegate = new TextBoxValidationDelegate();
            validationDelegate.clearIfNotNumber(txtCodProduto);
        }

        private void txtQuantidade_TextChanged(object sender, EventArgs e)
        {
            TextBoxValidationDelegate validationDelegate = new TextBoxValidationDelegate();
            validationDelegate.clearIfNotNumber(txtQuantidade);
        }


        private void button1_Click(object sender, EventArgs e)
        {
            FormRelatorio relatorio = new FormRelatorio();
            relatorio.Show();
        }

        private void vendaGridView_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            var NomeColuna = vendaGridView.Columns[e.ColumnIndex].Name;
            if (NomeColuna.Equals("Preco") || NomeColuna.Equals("Total"))
            {
                Double preco = Convert.ToDouble(e.Value);
                if (preco == null) return;
                e.Value = preco.ToString("F2");
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            var resultado = MessageBox.Show("Tem certeza que deseja cancelar?", "Cancelar Venda", MessageBoxButtons.OKCancel);
            if (resultado == DialogResult.OK)
            {
                vendaGridView.Rows.Clear();
                txtTotal.Clear();
                esconderBotaoVender();
            }
        }

        private void picFinalizar_Click(object sender, EventArgs e)
        {
            FrmVender.getInstance(bindingList.ToList(), _totalVenda, _funcionario).Show(); ;
        }

        private void esconderBotaoVender()
        {
            picFinalizar.Visible = false;
            labelVender.Visible = false;
        }

        private void mostrarBotaoVender()
        {
            picFinalizar.Visible = true;
            labelVender.Visible = true;
        }
    }
}
