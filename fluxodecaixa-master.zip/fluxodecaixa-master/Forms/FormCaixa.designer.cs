﻿namespace fluxodecaixa
{
    partial class Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Principal));
            this.btCadastroProduto = new System.Windows.Forms.Button();
            this.vendaGridView = new System.Windows.Forms.DataGridView();
            this.Nome = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Preco = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantidade = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.produtosBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.txtCodProduto = new System.Windows.Forms.TextBox();
            this.labl = new System.Windows.Forms.Label();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.txtQuantidade = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.labelTotal = new System.Windows.Forms.Label();
            this.labelVender = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblOperador = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.picFinalizar = new System.Windows.Forms.PictureBox();
            this.picCancelar = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.vendaGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.produtosBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFinalizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCancelar)).BeginInit();
            this.SuspendLayout();
            // 
            // btCadastroProduto
            // 
            this.btCadastroProduto.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btCadastroProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btCadastroProduto.Location = new System.Drawing.Point(647, 21);
            this.btCadastroProduto.Name = "btCadastroProduto";
            this.btCadastroProduto.Size = new System.Drawing.Size(105, 26);
            this.btCadastroProduto.TabIndex = 5;
            this.btCadastroProduto.Text = "Estoque";
            this.btCadastroProduto.UseVisualStyleBackColor = true;
            this.btCadastroProduto.Click += new System.EventHandler(this.btCadastroProduto_Click);
            // 
            // vendaGridView
            // 
            this.vendaGridView.AllowUserToAddRows = false;
            this.vendaGridView.AllowUserToDeleteRows = false;
            this.vendaGridView.AllowUserToResizeColumns = false;
            this.vendaGridView.AllowUserToResizeRows = false;
            this.vendaGridView.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.vendaGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.vendaGridView.BackgroundColor = System.Drawing.Color.MintCream;
            this.vendaGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.vendaGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Nome,
            this.Preco,
            this.Quantidade,
            this.Total});
            this.vendaGridView.Location = new System.Drawing.Point(152, 64);
            this.vendaGridView.Name = "vendaGridView";
            this.vendaGridView.ReadOnly = true;
            this.vendaGridView.RowHeadersWidth = 51;
            this.vendaGridView.Size = new System.Drawing.Size(600, 400);
            this.vendaGridView.TabIndex = 2;
            this.vendaGridView.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.vendaGridView_CellFormatting);
            // 
            // Nome
            // 
            this.Nome.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Nome.DataPropertyName = "Nome";
            this.Nome.HeaderText = "Nome";
            this.Nome.MinimumWidth = 6;
            this.Nome.Name = "Nome";
            this.Nome.ReadOnly = true;
            // 
            // Preco
            // 
            this.Preco.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.Preco.DataPropertyName = "Preco";
            this.Preco.HeaderText = "R$ (un)";
            this.Preco.MinimumWidth = 6;
            this.Preco.Name = "Preco";
            this.Preco.ReadOnly = true;
            this.Preco.Width = 67;
            // 
            // Quantidade
            // 
            this.Quantidade.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.Quantidade.DataPropertyName = "QtdVenda";
            this.Quantidade.HeaderText = "Quantidade";
            this.Quantidade.MinimumWidth = 6;
            this.Quantidade.Name = "Quantidade";
            this.Quantidade.ReadOnly = true;
            this.Quantidade.Width = 87;
            // 
            // Total
            // 
            this.Total.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Total.DataPropertyName = "Total";
            this.Total.HeaderText = "R$ (Total)";
            this.Total.MinimumWidth = 6;
            this.Total.Name = "Total";
            this.Total.ReadOnly = true;
            this.Total.Width = 79;
            // 
            // produtosBindingSource
            // 
            this.produtosBindingSource.DataMember = "Produtos";
            // 
            // txtCodProduto
            // 
            this.txtCodProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodProduto.Location = new System.Drawing.Point(19, 86);
            this.txtCodProduto.Name = "txtCodProduto";
            this.txtCodProduto.Size = new System.Drawing.Size(62, 28);
            this.txtCodProduto.TabIndex = 0;
            this.txtCodProduto.TextChanged += new System.EventHandler(this.txtCodProduto_TextChanged);
            this.txtCodProduto.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtCodProduto_KeyDown);
            // 
            // labl
            // 
            this.labl.AutoSize = true;
            this.labl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labl.Location = new System.Drawing.Point(16, 64);
            this.labl.Name = "labl";
            this.labl.Size = new System.Drawing.Size(59, 20);
            this.labl.TabIndex = 3;
            this.labl.Text = "Codigo";
            // 
            // txtTotal
            // 
            this.txtTotal.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTotal.Enabled = false;
            this.txtTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotal.Location = new System.Drawing.Point(650, 494);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(100, 28);
            this.txtTotal.TabIndex = 4;
            this.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtQuantidade
            // 
            this.txtQuantidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQuantidade.Location = new System.Drawing.Point(18, 158);
            this.txtQuantidade.Name = "txtQuantidade";
            this.txtQuantidade.Size = new System.Drawing.Size(81, 28);
            this.txtQuantidade.TabIndex = 1;
            this.txtQuantidade.TextChanged += new System.EventHandler(this.txtQuantidade_TextChanged);
            this.txtQuantidade.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtQuantidade_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(14, 135);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "Quantidade";
            // 
            // labelTotal
            // 
            this.labelTotal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.labelTotal.AutoSize = true;
            this.labelTotal.BackColor = System.Drawing.Color.Transparent;
            this.labelTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotal.Location = new System.Drawing.Point(562, 496);
            this.labelTotal.Name = "labelTotal";
            this.labelTotal.Size = new System.Drawing.Size(87, 24);
            this.labelTotal.TabIndex = 7;
            this.labelTotal.Text = "Total R$";
            // 
            // labelVender
            // 
            this.labelVender.AutoSize = true;
            this.labelVender.Location = new System.Drawing.Point(483, 527);
            this.labelVender.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelVender.Name = "labelVender";
            this.labelVender.Size = new System.Drawing.Size(81, 13);
            this.labelVender.TabIndex = 10;
            this.labelVender.Text = "Finalizar Pedido";
            this.labelVender.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(128, 525);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Cancelar Pedido";
            // 
            // lblOperador
            // 
            this.lblOperador.AutoSize = true;
            this.lblOperador.Location = new System.Drawing.Point(17, 11);
            this.lblOperador.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblOperador.Name = "lblOperador";
            this.lblOperador.Size = new System.Drawing.Size(0, 13);
            this.lblOperador.TabIndex = 12;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.button1.Location = new System.Drawing.Point(521, 21);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(105, 26);
            this.button1.TabIndex = 6;
            this.button1.Text = "Relatorios";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // picFinalizar
            // 
            this.picFinalizar.Image = ((System.Drawing.Image)(resources.GetObject("picFinalizar.Image")));
            this.picFinalizar.Location = new System.Drawing.Point(504, 485);
            this.picFinalizar.Name = "picFinalizar";
            this.picFinalizar.Size = new System.Drawing.Size(36, 39);
            this.picFinalizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picFinalizar.TabIndex = 13;
            this.picFinalizar.TabStop = false;
            this.picFinalizar.Visible = false;
            this.picFinalizar.Click += new System.EventHandler(this.picFinalizar_Click);
            // 
            // picCancelar
            // 
            this.picCancelar.Image = ((System.Drawing.Image)(resources.GetObject("picCancelar.Image")));
            this.picCancelar.Location = new System.Drawing.Point(152, 481);
            this.picCancelar.Name = "picCancelar";
            this.picCancelar.Size = new System.Drawing.Size(36, 39);
            this.picCancelar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCancelar.TabIndex = 14;
            this.picCancelar.TabStop = false;
            this.picCancelar.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(771, 556);
            this.Controls.Add(this.picCancelar);
            this.Controls.Add(this.picFinalizar);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblOperador);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.labelVender);
            this.Controls.Add(this.labelTotal);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtQuantidade);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.labl);
            this.Controls.Add(this.txtCodProduto);
            this.Controls.Add(this.vendaGridView);
            this.Controls.Add(this.btCadastroProduto);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Principal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Caixa";
            this.Load += new System.EventHandler(this.Principal_Load);
            ((System.ComponentModel.ISupportInitialize)(this.vendaGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.produtosBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFinalizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCancelar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btCadastroProduto;
        private System.Windows.Forms.BindingSource produtosBindingSource;
        private System.Windows.Forms.TextBox txtCodProduto;
        private System.Windows.Forms.Label labl;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.TextBox txtQuantidade;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelTotal;
        private System.Windows.Forms.DataGridView vendaGridView;
        private System.Windows.Forms.Label labelVender;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblOperador;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nome;
        private System.Windows.Forms.DataGridViewTextBoxColumn Preco;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantidade;
        private System.Windows.Forms.DataGridViewTextBoxColumn Total;
        private System.Windows.Forms.PictureBox picFinalizar;
        private System.Windows.Forms.PictureBox picCancelar;
    }
}

