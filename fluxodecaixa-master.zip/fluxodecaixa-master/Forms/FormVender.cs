﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using fluxodecaixa;
using fluxodecaixa.Forms;
using fluxodecaixa.Model;

namespace sys_caixa.Forms
{
    public partial class FrmVender : Form
    {
        private static FrmVender instance;
        private static Funcionario _operador;
        private static List<ItemVenda> _itensVenda = new List<ItemVenda>();
        private static double _total = 0;

        private const int A_VISTA = 0;
        private const int DEBITO = 1;
        private const int CREDITO = 2;
        private const int CREDITO_1_X = 3;
        private const int CREDITO_2_X = 4;
        private const int CREDITO_3_X = 5;
        private int formaDePagamentoAtual = A_VISTA;
        private Dictionary<int, string> formasPagamentos = new Dictionary<int, string>()
        {
            {A_VISTA, "A VISTA" },
            {DEBITO, "DÉBITO" },
            {CREDITO, "CRÉDITO" },
            {CREDITO_1_X, "CRÉDITO 1x" },
            {CREDITO_2_X, "CRÉDITO 2x" },
            {CREDITO_3_X, "CRÉDITO 3x" },
        };

        internal static FrmVender getInstance(List<ItemVenda> itensVenda, double total, Funcionario operador)
        {
            if (instance == null)
            {
                instance = new FrmVender(itensVenda, total, operador);
            }
            return instance;         
        }

        private FrmVender(List<ItemVenda> itensVenda,  double total, Funcionario operador)
        {
            _itensVenda.Clear();
            _itensVenda.AddRange(itensVenda);
            _total = total;
            _operador = operador;

            InitializeComponent();
            iniciarVenda();
        }


        private void btnPronto_Click(object sender, EventArgs e)
        {
            decimal falta = Convert.ToDecimal(lblFalta.Text);

            if (falta > 0)
            {
                DialogResult result = MessageBox.Show("Falta dinheiro. Tem certeza?", "Falta de dinheiro", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                    finalizar();
            }
            else
                finalizar();                
        }


        public void finalizar()
        {
            Cursor.Current = Cursors.WaitCursor;
            btnPronto.Enabled = false;

            using(var db = new DatabaseContexto())
            {
                try
                {
                    if(formaDePagamentoAtual != A_VISTA)
                    {
                        float taxa = pegarValorDescontoTaxa();
                        if(taxa > 0f)
                        {
                            _total -= _total * taxa;
                        }
                    }

                    Venda novaVenda = new Venda();
                    novaVenda.TimeStamp = DateTime.Now;
                    novaVenda.Valor = _total;
                    novaVenda.FormaPagamento = formasPagamentos[formaDePagamentoAtual];
                    db.Vendas.Add(novaVenda);
                    db.SaveChanges();

                    _itensVenda.ForEach(iten => { novaVenda.itensVenda.Add(iten); });
                    db.Vendas.Update(novaVenda);

                    var funcionario = db.Funcionarios.Where((f) => f.Id == _operador.Id).Single();
                    funcionario.Vendas.Add(novaVenda);
                    db.Funcionarios.Update(funcionario);
                    db.SaveChanges();

                    MessageBox.Show("Venda realizada com sucesso!", "Ok", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.Message);
                }
            }

            Principal.getInstance(_operador).reiniciarPedido();
            this.Close();
            Cursor.Current = Cursors.Default;
            btnPronto.Enabled = true;
        }


        private void txtDinheiro_TextChanged(object sender, EventArgs e)
        {
            if (txtDinheiro.Text.Length > 0)
            {
                var validation = new TextBoxValidationDelegate();
                validation.clearIfNotMoney(txtDinheiro);

                if (txtDinheiro.Text.Length > 0)
                {
                    checkConta();
                }
            }
        }


        public void checkConta()
        {
            double dinheiro = Convert.ToDouble(txtDinheiro.Text);
            double troco = _total - dinheiro;
            

            if(dinheiro == _total)
            {
                TrocoDefault();
                FaltaDefault();
            }


            if (dinheiro > _total)
            {
                lblTroco.BackColor = Color.PaleGreen;
                lblTroco.Text = StringUtil.formatToReais(troco * -1);
            }
            else
                TrocoDefault();


            if (dinheiro < _total)
            {
                lblFalta.BackColor = Color.Salmon;
                lblFalta.Text = StringUtil.formatToReais(troco);
            }
            else
                FaltaDefault();         
        }

        public void FaltaDefault()
        {
            lblFalta.Text = "00.00";
            lblFalta.BackColor = DefaultBackColor;
        }

        public void TrocoDefault()
        {
            lblTroco.Text = "00.00";
            lblTroco.BackColor = DefaultBackColor;
        }

        public void iniciarVenda()
        {
            lblTotal.Text = StringUtil.formatToReais(_total);
            lblFalta.Text = StringUtil.formatToReais(_total);
            lblFalta.BackColor = Color.Salmon;

            TrocoDefault();
        }

        private void txtDinheiro_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
            {
                txtDinheiro.Clear();
                iniciarVenda();
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmVender_FormClosing(object sender, FormClosingEventArgs e)
        {
            instance = null;
        }

        private void radioAVista_CheckedChanged(object sender, EventArgs e)
        {
            formaDePagamentoAtual = A_VISTA;
        }

        private void radioDebito_CheckedChanged(object sender, EventArgs e)
        {
            formaDePagamentoAtual = DEBITO;

        }

        private void radioCredito_CheckedChanged(object sender, EventArgs e)
        {
            formaDePagamentoAtual = CREDITO;
        }

        private void radioCredito1x_CheckedChanged(object sender, EventArgs e)
        {
            formaDePagamentoAtual = CREDITO_1_X;
        }

        private void radioCredito2x_CheckedChanged(object sender, EventArgs e)
        {
            formaDePagamentoAtual = CREDITO_2_X;
        }

        private void radioCredito3x_CheckedChanged(object sender, EventArgs e)
        {
            formaDePagamentoAtual = CREDITO_3_X;
        }


        private float pegarValorDescontoTaxa()
        {
            switch(formaDePagamentoAtual)
            {
                case DEBITO: return 0.0199f;
                case CREDITO: return 0.0319f;
                case CREDITO_1_X: return 0.0199f;
                case CREDITO_2_X: return 0.0758f;
                case CREDITO_3_X: return 0.0638f;
                default: return 0.0f;
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
