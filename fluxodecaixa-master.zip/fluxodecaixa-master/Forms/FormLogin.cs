﻿using System;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using fluxodecaixa.Forms;

namespace fluxodecaixa
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string id = txtCodFuncionario.Text;
            string senha = txtSenha.Text;

            using (var db = new DatabaseContexto())
            {
                try
                {
                    var resultado = db.Funcionarios.Where(f => f.Id == Int32.Parse(id) && f.Senha == senha).ToList();
                    if (resultado.Count <= 0)
                    {
                        MessageBox.Show("Usuario ou senha incorreto!");
                        txtCodFuncionario.Text = "";
                        txtSenha.Text = "";
                        txtCodFuncionario.Focus();
                        return;
                    }

                    Principal principal = Principal.getInstance(resultado.First());
                    principal.Show();
                    principal.FormClosing += (obj, args) => { this.Close(); };
                    this.Hide();
                }
                catch(Exception)
                {
                    MessageBox.Show("Algo errado aconteceu!");
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            frmGerente x = new frmGerente();
            x.Show();
        }

        private void txtSenha_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                button1_Click(sender, e);
            }
        }

        private void txtCodFuncionario_TextChanged(object sender, EventArgs e)
        {
            TextBoxValidationDelegate validationDelegate = new TextBoxValidationDelegate();
            validationDelegate.clearIfNotNumber(txtCodFuncionario);
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
