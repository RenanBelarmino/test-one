﻿namespace sys_caixa.Forms
{
    partial class FrmVender
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmVender));
            this.label1 = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtDinheiro = new System.Windows.Forms.TextBox();
            this.lblTrocoTitulo = new System.Windows.Forms.Label();
            this.lblTroco = new System.Windows.Forms.Label();
            this.lblFalta = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnPronto = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.radioDebito = new System.Windows.Forms.RadioButton();
            this.radioCredito = new System.Windows.Forms.RadioButton();
            this.radioCredito1x = new System.Windows.Forms.RadioButton();
            this.radioCredito2x = new System.Windows.Forms.RadioButton();
            this.radioCredito3x = new System.Windows.Forms.RadioButton();
            this.radioAVista = new System.Windows.Forms.RadioButton();
            this.groupPagamentos = new System.Windows.Forms.GroupBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AccessibleRole = System.Windows.Forms.AccessibleRole.TitleBar;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(22, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "TOTAL A PAGAR";
            // 
            // lblTotal
            // 
            this.lblTotal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTotal.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(166, 34);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(109, 37);
            this.lblTotal.TabIndex = 1;
            this.lblTotal.Text = "00.00";
            this.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(22, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 22);
            this.label2.TabIndex = 2;
            this.label2.Text = "DINHEIRO";
            // 
            // txtDinheiro
            // 
            this.txtDinheiro.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDinheiro.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDinheiro.Location = new System.Drawing.Point(166, 96);
            this.txtDinheiro.Name = "txtDinheiro";
            this.txtDinheiro.Size = new System.Drawing.Size(109, 26);
            this.txtDinheiro.TabIndex = 0;
            this.txtDinheiro.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDinheiro.TextChanged += new System.EventHandler(this.txtDinheiro_TextChanged);
            this.txtDinheiro.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtDinheiro_KeyDown);
            // 
            // lblTrocoTitulo
            // 
            this.lblTrocoTitulo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTrocoTitulo.AutoSize = true;
            this.lblTrocoTitulo.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTrocoTitulo.Location = new System.Drawing.Point(28, 367);
            this.lblTrocoTitulo.Name = "lblTrocoTitulo";
            this.lblTrocoTitulo.Size = new System.Drawing.Size(60, 22);
            this.lblTrocoTitulo.TabIndex = 3;
            this.lblTrocoTitulo.Text = "TROCO";
            // 
            // lblTroco
            // 
            this.lblTroco.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTroco.AutoEllipsis = true;
            this.lblTroco.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTroco.Location = new System.Drawing.Point(145, 352);
            this.lblTroco.Name = "lblTroco";
            this.lblTroco.Size = new System.Drawing.Size(130, 37);
            this.lblTroco.TabIndex = 5;
            this.lblTroco.Text = "00.00";
            this.lblTroco.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblFalta
            // 
            this.lblFalta.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblFalta.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFalta.Location = new System.Drawing.Point(139, 308);
            this.lblFalta.Name = "lblFalta";
            this.lblFalta.Size = new System.Drawing.Size(136, 37);
            this.lblFalta.TabIndex = 7;
            this.lblFalta.Text = "00.00";
            this.lblFalta.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(29, 323);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 22);
            this.label6.TabIndex = 6;
            this.label6.Text = "FALTA";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // btnPronto
            // 
            this.btnPronto.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPronto.BackColor = System.Drawing.Color.Green;
            this.btnPronto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPronto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnPronto.ForeColor = System.Drawing.Color.White;
            this.btnPronto.Location = new System.Drawing.Point(195, 427);
            this.btnPronto.Name = "btnPronto";
            this.btnPronto.Size = new System.Drawing.Size(80, 47);
            this.btnPronto.TabIndex = 1;
            this.btnPronto.Text = "Pronto";
            this.btnPronto.UseVisualStyleBackColor = false;
            this.btnPronto.Click += new System.EventHandler(this.btnPronto_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCancelar.BackColor = System.Drawing.Color.OrangeRed;
            this.btnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnCancelar.ForeColor = System.Drawing.Color.White;
            this.btnCancelar.Location = new System.Drawing.Point(26, 427);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(84, 47);
            this.btnCancelar.TabIndex = 2;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = false;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // radioDebito
            // 
            this.radioDebito.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.radioDebito.AutoSize = true;
            this.radioDebito.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioDebito.Location = new System.Drawing.Point(47, 216);
            this.radioDebito.Name = "radioDebito";
            this.radioDebito.Size = new System.Drawing.Size(74, 24);
            this.radioDebito.TabIndex = 8;
            this.radioDebito.Text = "Débito";
            this.radioDebito.UseVisualStyleBackColor = true;
            this.radioDebito.CheckedChanged += new System.EventHandler(this.radioDebito_CheckedChanged);
            // 
            // radioCredito
            // 
            this.radioCredito.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.radioCredito.AutoSize = true;
            this.radioCredito.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioCredito.Location = new System.Drawing.Point(47, 245);
            this.radioCredito.Name = "radioCredito";
            this.radioCredito.Size = new System.Drawing.Size(78, 24);
            this.radioCredito.TabIndex = 9;
            this.radioCredito.Text = "Crédito";
            this.radioCredito.UseVisualStyleBackColor = true;
            this.radioCredito.CheckedChanged += new System.EventHandler(this.radioCredito_CheckedChanged);
            // 
            // radioCredito1x
            // 
            this.radioCredito1x.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.radioCredito1x.AutoSize = true;
            this.radioCredito1x.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioCredito1x.Location = new System.Drawing.Point(162, 184);
            this.radioCredito1x.Name = "radioCredito1x";
            this.radioCredito1x.Size = new System.Drawing.Size(98, 24);
            this.radioCredito1x.TabIndex = 10;
            this.radioCredito1x.Text = "Crédito 1x";
            this.radioCredito1x.UseVisualStyleBackColor = true;
            this.radioCredito1x.CheckedChanged += new System.EventHandler(this.radioCredito1x_CheckedChanged);
            // 
            // radioCredito2x
            // 
            this.radioCredito2x.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.radioCredito2x.AutoSize = true;
            this.radioCredito2x.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioCredito2x.Location = new System.Drawing.Point(162, 215);
            this.radioCredito2x.Name = "radioCredito2x";
            this.radioCredito2x.Size = new System.Drawing.Size(98, 24);
            this.radioCredito2x.TabIndex = 11;
            this.radioCredito2x.Text = "Crédito 2x";
            this.radioCredito2x.UseVisualStyleBackColor = true;
            this.radioCredito2x.CheckedChanged += new System.EventHandler(this.radioCredito2x_CheckedChanged);
            // 
            // radioCredito3x
            // 
            this.radioCredito3x.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.radioCredito3x.AutoSize = true;
            this.radioCredito3x.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioCredito3x.Location = new System.Drawing.Point(162, 245);
            this.radioCredito3x.Name = "radioCredito3x";
            this.radioCredito3x.Size = new System.Drawing.Size(98, 24);
            this.radioCredito3x.TabIndex = 12;
            this.radioCredito3x.Text = "Crédito 3x";
            this.radioCredito3x.UseVisualStyleBackColor = true;
            this.radioCredito3x.CheckedChanged += new System.EventHandler(this.radioCredito3x_CheckedChanged);
            // 
            // radioAVista
            // 
            this.radioAVista.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.radioAVista.AutoSize = true;
            this.radioAVista.Checked = true;
            this.radioAVista.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioAVista.Location = new System.Drawing.Point(47, 188);
            this.radioAVista.Name = "radioAVista";
            this.radioAVista.Size = new System.Drawing.Size(78, 24);
            this.radioAVista.TabIndex = 13;
            this.radioAVista.TabStop = true;
            this.radioAVista.Text = "À Vista";
            this.radioAVista.UseVisualStyleBackColor = true;
            this.radioAVista.CheckedChanged += new System.EventHandler(this.radioAVista_CheckedChanged);
            // 
            // groupPagamentos
            // 
            this.groupPagamentos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupPagamentos.AutoSize = true;
            this.groupPagamentos.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupPagamentos.Location = new System.Drawing.Point(26, 165);
            this.groupPagamentos.Name = "groupPagamentos";
            this.groupPagamentos.Size = new System.Drawing.Size(249, 113);
            this.groupPagamentos.TabIndex = 15;
            this.groupPagamentos.TabStop = false;
            this.groupPagamentos.Text = "PAGAMENTO";
            // 
            // FrmVender
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(307, 514);
            this.Controls.Add(this.radioAVista);
            this.Controls.Add(this.radioCredito3x);
            this.Controls.Add(this.radioCredito2x);
            this.Controls.Add(this.radioCredito1x);
            this.Controls.Add(this.radioCredito);
            this.Controls.Add(this.radioDebito);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnPronto);
            this.Controls.Add(this.lblFalta);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblTroco);
            this.Controls.Add(this.lblTrocoTitulo);
            this.Controls.Add(this.txtDinheiro);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupPagamentos);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmVender";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FINALIZAR PEDIDO";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmVender_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtDinheiro;
        private System.Windows.Forms.Label lblTrocoTitulo;
        private System.Windows.Forms.Label lblTroco;
        private System.Windows.Forms.Label lblFalta;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnPronto;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.RadioButton radioDebito;
        private System.Windows.Forms.RadioButton radioCredito;
        private System.Windows.Forms.RadioButton radioCredito1x;
        private System.Windows.Forms.RadioButton radioCredito2x;
        private System.Windows.Forms.RadioButton radioCredito3x;
        private System.Windows.Forms.RadioButton radioAVista;
        private System.Windows.Forms.GroupBox groupPagamentos;
    }
}