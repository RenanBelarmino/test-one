﻿using fluxodecaixa.Model;
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace fluxodecaixa
{
    public partial class FormCadastroFuncionario : Form
    {
        public FormCadastroFuncionario()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Funcionario funcionario = new Funcionario();
            funcionario.Nome = txtNome.Text;
            funcionario.Senha = txtSenha.Text;
            funcionario.IsAdmin = false;

            using(var db = new DatabaseContexto())
            {
                db.Funcionarios.Add(funcionario);
                db.SaveChanges();
            }

            MessageBox.Show(
                "Guarde esse código, ele vai servir pra voÇê fazer login \n " +
                "\t>>>>>>> " + funcionario.Id + " <<<<<<<",
                "Cadastrado com sucesso!",
                MessageBoxButtons.OK
            );

            this.Hide();
            this.Close();
        }

        private void txtSenha_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                button1_Click(sender, e);
            }
        }
    }
}
