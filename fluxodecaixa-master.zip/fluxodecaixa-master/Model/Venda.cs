﻿using System;
using System.Collections.Generic;

namespace fluxodecaixa.Model
{
    class Venda
    {
        public int Id { get; set; }

        public Funcionario Funcionario { get; set; }

        public double Valor { get; set; }

        public string FormaPagamento { get; set; }

        public ICollection<ItemVenda> itensVenda { get; } = new List<ItemVenda>();

        public DateTime TimeStamp { get; set; }
    }
}
