﻿using System.Collections.Generic;

namespace fluxodecaixa.Model
{
    class Produto
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public double PrecoVenda { get; set; }
        public double PrecoCusto { get; set; }
        public int QtdEstoque { get; set; }

        public Fornecedor Fornecedor { get; set; }

        public ICollection<ItemVenda> itensVenda { get; set; } = new List<ItemVenda>();
    }
}
