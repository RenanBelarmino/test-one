﻿using System.Collections.Generic;

namespace fluxodecaixa.Model
{
    class Funcionario
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Senha { get; set; }

        public bool IsAdmin { get; set; }

        public ICollection<Venda> Vendas { get; } = new List<Venda>();

    }
}
