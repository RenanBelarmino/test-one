﻿using fluxodecaixa.Model;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;

namespace fluxodecaixa
{
    class DatabaseContexto : DbContext
    {
        public DbSet<Funcionario> Funcionarios { get; set; }

        public DbSet<Produto> Produtos { get; set; }
        public DbSet<Venda> Vendas { get; set; }
        public DbSet<ItemVenda> ItensVenda { get; set; }
        public DbSet<Fornecedor> Fornecedores { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            var local = (System.AppDomain.CurrentDomain.BaseDirectory + @"\database.db");
            string StringConection = @"Data Source=.\database.db";
            optionsBuilder.UseSqlite(StringConection);
            base.OnConfiguring(optionsBuilder);
        }

        //public DatabaseContexto(DbContextOptions<DatabaseContexto> opcoes): base(opcoes) { }

        //public DbSet<Funcionario> Funcionarios { get; set; }

        //protected override void OnModelCreating(ModelBuilder builder)
        // {
        //      builder.Entity<Funcionario>().HasKey(m => m.Id);
        //     base.OnModelCreating(builder);
        //    }
    }
}
