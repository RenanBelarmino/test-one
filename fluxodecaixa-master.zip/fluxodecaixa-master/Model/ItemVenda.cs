﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fluxodecaixa.Model
{
    class ItemVenda
    {
        public ItemVenda(int qtdVenda)
        {
            this.QtdVenda = qtdVenda;
        }

        public int Id { get; set; }

        public Venda Venda { get; set; }

        public Produto Produto { get; set; }

        public int QtdVenda { get; set; }

        public string Nome { get { return Produto.Nome; } }

        public double Preco { get { return Produto.PrecoVenda; } }
 
        public double Total { get { return (QtdVenda * Preco); } }
    }
}
